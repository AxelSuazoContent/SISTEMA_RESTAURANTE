# 🍽️ Sistema de Gestión de Restaurante

Sistema completo para la gestión de restaurantes desarrollado con **Laravel 10** y **PHP 8+**. Incluye módulos de Punto de Venta (POS), Vista de Cocina y Panel de Administración.

## 📋 Características

### 🖥️ Sistema POS (Punto de Venta)
- Toma de pedidos en mesa, para llevar o a domicilio
- Gestión visual de mesas con estados en tiempo real
- Búsqueda rápida de productos por categoría
- Ticket de venta con edición de cantidades y notas
- Proceso de cobro con múltiples métodos de pago
- Impresión de tickets

### 👨‍🍳 Vista de Cocina
- Visualización de pedidos pendientes en tiempo real
- Control de estados: Pendiente → En preparación → Listo
- Indicador de tiempo transcurrido
- Alertas visuales para pedidos urgentes
- Actualización automática (polling)
- Sonido de notificación para nuevos pedidos

### 📊 Panel de Administración
- Dashboard con estadísticas del día
- Gestión de usuarios (Admin, Recepcionista, Cocina)
- Gestión de categorías de productos
- Gestión de productos con control de stock
- Gestión de mesas
- Reporte de ventas con filtros por fecha

## 🚀 Requisitos

- PHP >= 8.1
- Composer >= 2.0
- MySQL >= 5.7 o MariaDB >= 10.3
- Node.js >= 18.0 (opcional, para assets)

## ⚙️ Instalación

### Paso 1: Clonar o descargar el proyecto

```bash
cd /ruta/deseada
copia la carpeta restaurante-laravel
```

### Paso 2: Instalar dependencias de PHP

```bash
cd restaurante-laravel
composer install
```

### Paso 3: Configurar el archivo de entorno

```bash
cp .env.example .env
```

Edita el archivo `.env` con tus configuraciones:

```env
APP_NAME="Sistema Restaurante"
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=restaurante
DB_USERNAME=root
DB_PASSWORD=tu_password
```

### Paso 4: Generar la clave de la aplicación

```bash
php artisan key:generate
```

### Paso 5: Crear la base de datos

Crea una base de datos llamada `restaurante` en tu servidor MySQL:

```sql
CREATE DATABASE restaurante CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Paso 6: Ejecutar migraciones y seeders

```bash
php artisan migrate --seed
```

Esto creará todas las tablas y cargará datos de prueba incluyendo:
- 5 usuarios (admin, recepcionistas, cocineros)
- 7 categorías de productos
- 35 productos de ejemplo
- 20 mesas

### Paso 7: Crear enlace simbólico para storage

```bash
php artisan storage:link
```

### Paso 8: Iniciar el servidor

```bash
php artisan serve
```

Visita: `http://127.0.0.1:8000`

## 👤 Usuarios de Prueba

| Rol | Email | Contraseña |
|-----|-------|------------|
| Administrador | admin@restaurante.com | password |
| Recepcionista | recepcion@restaurante.com | password |
| Cocina | cocina@restaurante.com | password |

## 📁 Estructura del Proyecto

```
restaurante-laravel/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AdminController.php      # Gestión administrativa
│   │   │   ├── AuthController.php       # Autenticación
│   │   │   ├── CocinaController.php     # Vista de cocina
│   │   │   └── POSController.php        # Punto de venta
│   │   └── Middleware/
│   ├── Models/
│   │   ├── Categoria.php
│   │   ├── DetallePedido.php
│   │   ├── Mesa.php
│   │   ├── Pago.php
│   │   ├── Pedido.php
│   │   ├── Producto.php
│   │   └── User.php
│   └── Providers/
├── config/
├── database/
│   ├── migrations/          # Todas las migraciones
│   └── seeders/             # Seeders con datos de prueba
├── public/                  # Carpeta pública
├── resources/
│   └── views/               # Vistas Blade
│       ├── admin/           # Panel admin
│       ├── auth/            # Login
│       ├── cocina/          # Vista cocina
│       ├── layouts/         # Layouts base
│       └── pos/             # Punto de venta
├── routes/
│   └── web.php              # Rutas de la aplicación
└── .env                     # Configuración de entorno
```

## 🔐 Roles y Permisos

### Administrador
- Acceso completo al sistema
- Dashboard con estadísticas
- Gestión de usuarios
- Gestión de categorías y productos
- Gestión de mesas
- Reportes de ventas
- Acceso a POS y Cocina

### Recepcionista
- Acceso al POS (Punto de Venta)
- Toma de pedidos
- Gestión de mesas
- Proceso de cobro

### Cocina
- Acceso a Vista de Cocina
- Visualización de pedidos pendientes
- Control de preparación de alimentos
- Marcado de pedidos como listos

## 🔄 Estados del Sistema

### Estados de Mesas
- **Disponible**: Mesa libre para nuevos clientes
- **Ocupada**: Mesa con pedido activo
- **Reservada**: Mesa reservada
- **En limpieza**: Mesa en proceso de limpieza

### Estados de Pedidos
- **Pendiente**: Pedido recién creado
- **En preparación**: Cocina trabajando en el pedido
- **Listo**: Pedido listo para entregar
- **Entregado**: Pedido entregado al cliente
- **Pagado**: Pedido pagado y completado
- **Cancelado**: Pedido cancelado

### Estados de Items (Detalle)
- **Pendiente**: Item esperando preparación
- **En preparación**: Item siendo preparado
- **Listo**: Item listo
- **Entregado**: Item entregado

## 💰 Métodos de Pago

- Efectivo (con cálculo de cambio)
- Tarjeta de crédito/débito
- Transferencia bancaria
- Otros métodos

## 📊 Reportes

El sistema incluye reporte de ventas con:
- Filtros por rango de fechas
- Total de ventas en el período
- Cantidad de pedidos
- Detalle de cada transacción
- Método de pago utilizado

## 🛠️ Comandos Útiles

```bash
# Limpiar caché
php artisan cache:clear
php artisan config:clear
php artisan view:clear

# Reiniciar base de datos (⚠️ Elimina todos los datos)
php artisan migrate:fresh --seed

# Crear usuario administrador manualmente
php artisan tinker
>>> \App\Models\User::create(['nombre' => 'Admin', 'email' => 'admin@nuevo.com', 'password' => bcrypt('password'), 'rol' => 'admin'])
```

## 🐛 Solución de Problemas

### Error: "No such file or directory" al instalar
```bash
# Asegúrate de tener Composer instalado
composer --version

# Si no lo tienes, instálalo desde:
# https://getcomposer.org/download/
```

### Error de permisos en storage
```bash
# Linux/Mac
chmod -R 755 storage
chmod -R 755 bootstrap/cache

# Windows (como administrador)
icacls storage /grant Everyone:F /T
```

### Error: "Access denied for user"
Verifica que las credenciales en el archivo `.env` sean correctas y que el usuario tenga permisos en la base de datos.

### Error: "Table doesn't exist"
Ejecuta las migraciones:
```bash
php artisan migrate
```

## 🔒 Seguridad

- Todas las contraseñas están encriptadas con bcrypt
- Protección contra CSRF en todos los formularios
- Validación de datos en servidor
- Control de acceso basado en roles
- Sesiones seguras

## 📝 Notas

- El sistema está configurado en español por defecto
- Zona horaria: America/Mexico_City
- Moneda: Pesos ($)
- Formato de fecha: dd/mm/YYYY

## 📄 Licencia

Este proyecto es de código abierto y puede ser utilizado libremente para fines comerciales o personales.

## 🤝 Soporte

Para reportar problemas o sugerir mejoras, por favor crea un issue en el repositorio.

---

**Desarrollado con ❤️ usando Laravel**

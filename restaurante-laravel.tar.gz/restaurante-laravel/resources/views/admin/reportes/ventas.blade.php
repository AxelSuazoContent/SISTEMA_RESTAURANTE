@extends('layouts.app')

@section('title', 'Reporte de Ventas')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="bi bi-graph-up"></i> Reporte de Ventas</h1>
    <button onclick="window.print()" class="btn btn-outline-primary no-print">
        <i class="bi bi-printer"></i> Imprimir
    </button>
</div>

<!-- Filtros -->
<div class="card mb-4 no-print">
    <div class="card-body">
        <form method="GET" action="{{ route('admin.reportes.ventas') }}" class="row g-3">
            <div class="col-md-4">
                <label for="fecha_inicio" class="form-label">Fecha Inicio</label>
                <input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio" 
                       value="{{ $fechaInicio->format('Y-m-d') }}">
            </div>
            <div class="col-md-4">
                <label for="fecha_fin" class="form-label">Fecha Fin</label>
                <input type="date" class="form-control" id="fecha_fin" name="fecha_fin" 
                       value="{{ $fechaFin->format('Y-m-d') }}">
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search"></i> Filtrar
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Resumen -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h4 class="card-title">Total Ventas</h4>
                <h2>${{ number_format($totalVentas, 2) }}</h2>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h4 class="card-title">Total Pedidos</h4>
                <h2>{{ $totalPedidos }}</h2>
            </div>
        </div>
    </div>
</div>

<!-- Tabla de Ventas -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-list"></i> Detalle de Ventas
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th># Pedido</th>
                        <th>Fecha</th>
                        <th>Mesa/Cliente</th>
                        <th>Atendió</th>
                        <th>Total</th>
                        <th>Método de Pago</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($ventas as $venta)
                    <tr>
                        <td>#{{ $venta->id }}</td>
                        <td>{{ $venta->created_at->format('d/m/Y H:i') }}</td>
                        <td>
                            @if($venta->mesa)
                                Mesa {{ $venta->mesa->numero }}
                            @else
                                {{ $venta->cliente_nombre ?: 'Sin nombre' }}
                            @endif
                        </td>
                        <td>{{ $venta->usuario->nombre }}</td>
                        <td>${{ number_format($venta->total, 2) }}</td>
                        <td>
                            @if($venta->pago)
                                {{ $venta->pago->metodo_pago_formateado }}
                            @else
                                -
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            No hay ventas en el período seleccionado
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @if($ventas->hasPages())
    <div class="card-footer no-print">
        {{ $ventas->links() }}
    </div>
    @endif
</div>
@endsection

@extends('layouts.app')

@section('title', 'Mesas')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="bi bi-grid-3x3"></i> Mesas</h1>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCrear">
        <i class="bi bi-plus-lg"></i> Nueva Mesa
    </button>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Número</th>
                        <th>Capacidad</th>
                        <th>Ubicación</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($mesas as $mesa)
                    <tr>
                        <td><strong>#{{ $mesa->numero }}</strong></td>
                        <td>{{ $mesa->capacidad }} personas</td>
                        <td>{{ $mesa->ubicacion ?: '-' }}</td>
                        <td>
                            <span class="badge-estado estado-{{ $mesa->estado }}">
                                {{ $mesa->estado_formateado }}
                            </span>
                        </td>
                        <td>
                            <button type="button" class="btn btn-sm btn-warning" data-bs-toggle="modal" 
                                    data-bs-target="#modalEditar{{ $mesa->id }}">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <form action="{{ route('admin.mesas.destroy', $mesa) }}" method="POST" class="d-inline" 
                                  onsubmit="return confirm('¿Estás seguro de eliminar esta mesa?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            No hay mesas registradas
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @if($mesas->hasPages())
    <div class="card-footer">
        {{ $mesas->links() }}
    </div>
    @endif
</div>

<!-- Modal Crear -->
<div class="modal fade" id="modalCrear" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="{{ route('admin.mesas.store') }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Nueva Mesa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="numero" class="form-label">Número *</label>
                        <input type="number" class="form-control" id="numero" name="numero" required min="1">
                    </div>
                    <div class="mb-3">
                        <label for="capacidad" class="form-label">Capacidad (personas) *</label>
                        <input type="number" class="form-control" id="capacidad" name="capacidad" required min="1" value="4">
                    </div>
                    <div class="mb-3">
                        <label for="ubicacion" class="form-label">Ubicación</label>
                        <input type="text" class="form-control" id="ubicacion" name="ubicacion" 
                               placeholder="Ej: Interior, Terraza, etc.">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modales Editar -->
@foreach($mesas as $mesa)
<div class="modal fade" id="modalEditar{{ $mesa->id }}" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="{{ route('admin.mesas.update', $mesa) }}">
                @csrf
                @method('PUT')
                <div class="modal-header">
                    <h5 class="modal-title">Editar Mesa #{{ $mesa->numero }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="numero{{ $mesa->id }}" class="form-label">Número *</label>
                        <input type="number" class="form-control" id="numero{{ $mesa->id }}" 
                               name="numero" value="{{ $mesa->numero }}" required min="1">
                    </div>
                    <div class="mb-3">
                        <label for="capacidad{{ $mesa->id }}" class="form-label">Capacidad (personas) *</label>
                        <input type="number" class="form-control" id="capacidad{{ $mesa->id }}" 
                               name="capacidad" value="{{ $mesa->capacidad }}" required min="1">
                    </div>
                    <div class="mb-3">
                        <label for="ubicacion{{ $mesa->id }}" class="form-label">Ubicación</label>
                        <input type="text" class="form-control" id="ubicacion{{ $mesa->id }}" 
                               name="ubicacion" value="{{ $mesa->ubicacion }}">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endforeach
@endsection

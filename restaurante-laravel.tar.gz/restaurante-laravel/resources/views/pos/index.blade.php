@extends('layouts.app')

@section('title', 'Punto de Venta')

@section('styles')
<style>
    .mesa-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 10px;
    }
    .mesa-item {
        aspect-ratio: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s;
        font-weight: 600;
    }
    .mesa-item:hover {
        transform: scale(1.05);
    }
    .mesa-disponible { background-color: #d4edda; color: #155724; border: 2px solid #28a745; }
    .mesa-ocupada { background-color: #f8d7da; color: #721c24; border: 2px solid #dc3545; }
    .mesa-reservada { background-color: #fff3cd; color: #856404; border: 2px solid #ffc107; }
    .mesa-limpieza { background-color: #d1ecf1; color: #0c5460; border: 2px solid #17a2b8; }
    
    .categoria-tabs {
        overflow-x: auto;
        white-space: nowrap;
    }
    .categoria-tabs .nav-link {
        border-radius: 20px;
        margin-right: 5px;
        color: #555;
    }
    .categoria-tabs .nav-link.active {
        background-color: var(--primary-color);
        color: white !important;
    }
    
    .producto-item {
        cursor: pointer;
        transition: all 0.2s;
        border: 2px solid transparent;
    }
    .producto-item:hover {
        border-color: var(--primary-color);
        transform: translateY(-2px);
    }
    .producto-item .precio {
        font-weight: 600;
        color: var(--success-color);
    }
    
    .ticket-item {
        border-bottom: 1px solid #eee;
        padding: 10px 0;
    }
    .ticket-item:last-child {
        border-bottom: none;
    }
    
    .cantidad-control {
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .cantidad-control button {
        width: 25px;
        height: 25px;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    #ticketPanel {
        max-height: calc(100vh - 300px);
        overflow-y: auto;
    }
</style>
@endsection

@section('content')
<div class="row">
    <!-- Panel Izquierdo: Mesas y Productos -->
    <div class="col-lg-8">
        <!-- Selector de Tipo -->
        <div class="card mb-3">
            <div class="card-body">
                <div class="btn-group w-100" role="group">
                    <input type="radio" class="btn-check" name="tipoPedido" id="tipoMesa" value="mesa" checked>
                    <label class="btn btn-outline-primary" for="tipoMesa">
                        <i class="bi bi-grid-3x3"></i> En Mesa
                    </label>
                    
                    <input type="radio" class="btn-check" name="tipoPedido" id="tipoLlevar" value="llevar">
                    <label class="btn btn-outline-primary" for="tipoLlevar">
                        <i class="bi bi-bag"></i> Para Llevar
                    </label>
                    
                    <input type="radio" class="btn-check" name="tipoPedido" id="tipoDomicilio" value="domicilio">
                    <label class="btn btn-outline-primary" for="tipoDomicilio">
                        <i class="bi bi-house"></i> A Domicilio
                    </label>
                </div>
            </div>
        </div>

        <!-- Selector de Mesa -->
        <div class="card mb-3" id="mesaSelector">
            <div class="card-header">
                <i class="bi bi-grid-3x3"></i> Seleccionar Mesa
            </div>
            <div class="card-body">
                <div class="mesa-grid">
                    @foreach($mesas as $mesa)
                    <div class="mesa-item mesa-{{ $mesa->estado }}" 
                         data-mesa-id="{{ $mesa->id }}"
                         data-mesa-numero="{{ $mesa->numero }}"
                         data-mesa-estado="{{ $mesa->estado }}"
                         onclick="seleccionarMesa({{ $mesa->id }}, {{ $mesa->numero }}, '{{ $mesa->estado }}')">
                        <i class="bi bi-{{ $mesa->capacidad > 4 ? 'people' : 'person' }}" style="font-size: 1.5rem;"></i>
                        <span>{{ $mesa->numero }}</span>
                        <small>{{ $mesa->capacidad }}p</small>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Datos Cliente (para llevar/domicilio) -->
        <div class="card mb-3 d-none" id="clienteDatos">
            <div class="card-header">
                <i class="bi bi-person"></i> Datos del Cliente
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <input type="text" class="form-control" id="clienteNombre" placeholder="Nombre del cliente">
                    </div>
                    <div class="col-md-6 mb-2">
                        <input type="tel" class="form-control" id="clienteTelefono" placeholder="Teléfono">
                    </div>
                </div>
            </div>
        </div>

        <!-- Categorías -->
        <div class="card mb-3">
            <div class="card-body p-2">
                <div class="categoria-tabs">
                    <ul class="nav nav-pills" id="categoriasTab">
                        <li class="nav-item">
                            <a class="nav-link active" href="#" data-categoria="todas">Todas</a>
                        </li>
                        @foreach($categorias as $categoria)
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-categoria="{{ $categoria->id }}" 
                               style="background-color: {{ $categoria->color }}20; color: {{ $categoria->color }};">
                                {{ $categoria->nombre }}
                            </a>
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>

        <!-- Productos -->
        <div class="card">
            <div class="card-body">
                <div class="row g-3" id="productosGrid">
                    @foreach($categorias as $categoria)
                        @foreach($categoria->productos as $producto)
                        <div class="col-6 col-md-4 col-lg-3 producto-wrapper" data-categoria="{{ $categoria->id }}">
                            <div class="card producto-item h-100" onclick="agregarProducto({{ $producto->id }}, '{{ $producto->nombre }}', {{ $producto->precio }})">
                                @if($producto->imagen)
                                    <img src="{{ asset('storage/' . $producto->imagen) }}" 
                                         class="card-img-top" 
                                         alt="{{ $producto->nombre }}"
                                         style="height: 100px; object-fit: cover;">
                                @else
                                    <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 100px;">
                                        <i class="bi bi-image text-muted" style="font-size: 2rem;"></i>
                                    </div>
                                @endif
                                <div class="card-body p-2 text-center">
                                    <h6 class="card-title mb-1" style="font-size: 0.9rem;">{{ $producto->nombre }}</h6>
                                    <p class="precio mb-0">${{ number_format($producto->precio, 2) }}</p>
                                    @if($producto->stock < 10)
                                        <small class="text-danger">Stock: {{ $producto->stock }}</small>
                                    @endif
                                </div>
                            </div>
                        </div>
                        @endforeach
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    <!-- Panel Derecho: Ticket -->
    <div class="col-lg-4">
        <div class="card sticky-top" style="top: 20px;">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-receipt"></i> Ticket</span>
                    <span id="infoMesa">Sin mesa</span>
                </div>
            </div>
            <div class="card-body p-0">
                <div id="ticketPanel" class="p-3">
                    <div id="ticketVacio" class="text-center text-muted py-5">
                        <i class="bi bi-cart" style="font-size: 3rem;"></i>
                        <p class="mt-2">Agrega productos al ticket</p>
                    </div>
                    <div id="ticketItems"></div>
                </div>
            </div>
            <div class="card-footer">
                <div class="d-flex justify-content-between mb-2">
                    <span>Subtotal:</span>
                    <strong id="subtotal">$0.00</strong>
                </div>
                <div class="d-flex justify-content-between mb-3">
                    <span>Total:</span>
                    <h4 class="mb-0 text-success" id="total">$0.00</h4>
                </div>
                <div class="d-grid gap-2">
                    <button class="btn btn-danger" id="btnCancelar" onclick="cancelarTicket()" disabled>
                        <i class="bi bi-x-lg"></i> Cancelar
                    </button>
                    <button class="btn btn-success btn-lg" id="btnEnviar" onclick="enviarPedido()" disabled>
                        <i class="bi bi-send"></i> Enviar Pedido
                    </button>
                </div>
            </div>
        </div>

        <!-- Pedidos Activos -->
        <div class="card mt-3">
            <div class="card-header">
                <i class="bi bi-clock-history"></i> Pedidos Activos
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush" id="pedidosActivos">
                    @forelse($pedidosActivos as $pedido)
                    <a href="#" class="list-group-item list-group-item-action" onclick="cargarPedido({{ $pedido->id }})">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">
                                @if($pedido->mesa)
                                    Mesa {{ $pedido->mesa->numero }}
                                @else
                                    {{ $pedido->cliente_nombre ?: 'Sin nombre' }}
                                @endif
                            </h6>
                            <small class="text-muted">{{ $pedido->tiempo_transcurrido }}</small>
                        </div>
                        <p class="mb-1">${{ number_format($pedido->total, 2) }}</p>
                        <span class="badge-estado estado-{{ $pedido->estado }}">
                            {{ $pedido->estado_formateado }}
                        </span>
                    </a>
                    @empty
                    <div class="list-group-item text-center text-muted py-3">
                        No hay pedidos activos
                    </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Cobrar -->
<div class="modal fade" id="modalCobrar" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cobrar Pedido</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Total a Pagar</label>
                    <h3 class="text-success" id="totalCobrar">$0.00</h3>
                </div>
                <div class="mb-3">
                    <label for="metodoPago" class="form-label">Método de Pago</label>
                    <select class="form-select" id="metodoPago">
                        <option value="efectivo">Efectivo</option>
                        <option value="tarjeta">Tarjeta</option>
                        <option value="transferencia">Transferencia</option>
                        <option value="otro">Otro</option>
                    </select>
                </div>
                <div class="mb-3" id="campoEfectivo">
                    <label for="montoRecibido" class="form-label">Monto Recibido</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" class="form-control" id="montoRecibido" step="0.01">
                    </div>
                </div>
                <div class="mb-3 d-none" id="campoReferencia">
                    <label for="referenciaPago" class="form-label">Referencia</label>
                    <input type="text" class="form-control" id="referenciaPago">
                </div>
                <div class="mb-3" id="campoCambio">
                    <label class="form-label">Cambio</label>
                    <h4 class="text-primary" id="cambio">$0.00</h4>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-success" onclick="procesarPago()">
                    <i class="bi bi-check-lg"></i> Cobrar
                </button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
let ticket = [];
let mesaSeleccionada = null;
let pedidoActual = null;

// Cambiar tipo de pedido
document.querySelectorAll('input[name="tipoPedido"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const tipo = this.value;
        if (tipo === 'mesa') {
            document.getElementById('mesaSelector').classList.remove('d-none');
            document.getElementById('clienteDatos').classList.add('d-none');
        } else {
            document.getElementById('mesaSelector').classList.add('d-none');
            document.getElementById('clienteDatos').classList.remove('d-none');
            mesaSeleccionada = null;
            document.getElementById('infoMesa').textContent = tipo === 'llevar' ? 'Para llevar' : 'A domicilio';
        }
    });
});

// Filtrar productos por categoría
document.querySelectorAll('#categoriasTab .nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('#categoriasTab .nav-link').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
        
        const categoria = this.dataset.categoria;
        document.querySelectorAll('.producto-wrapper').forEach(wrapper => {
            if (categoria === 'todas' || wrapper.dataset.categoria === categoria) {
                wrapper.classList.remove('d-none');
            } else {
                wrapper.classList.add('d-none');
            }
        });
    });
});

function seleccionarMesa(id, numero, estado) {
    if (estado === 'ocupada') {
        // Cargar pedido existente
        cargarPedidoMesa(id);
        return;
    }
    mesaSeleccionada = id;
    document.getElementById('infoMesa').textContent = 'Mesa ' + numero;
    
    // Resaltar mesa seleccionada
    document.querySelectorAll('.mesa-item').forEach(item => {
        item.style.opacity = '0.5';
    });
    document.querySelector(`[data-mesa-id="${id}"]`).style.opacity = '1';
}

function agregarProducto(id, nombre, precio) {
    const existente = ticket.find(item => item.id === id);
    if (existente) {
        existente.cantidad++;
    } else {
        ticket.push({ id, nombre, precio, cantidad: 1, notas: '' });
    }
    actualizarTicket();
}

function actualizarTicket() {
    const container = document.getElementById('ticketItems');
    const vacio = document.getElementById('ticketVacio');
    
    if (ticket.length === 0) {
        vacio.classList.remove('d-none');
        container.innerHTML = '';
        document.getElementById('btnEnviar').disabled = true;
        document.getElementById('btnCancelar').disabled = true;
    } else {
        vacio.classList.add('d-none');
        document.getElementById('btnEnviar').disabled = false;
        document.getElementById('btnCancelar').disabled = false;
        
        container.innerHTML = ticket.map((item, index) => `
            <div class="ticket-item">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <strong>${item.nombre}</strong>
                        <div class="text-muted">$${item.precio.toFixed(2)} c/u</div>
                    </div>
                    <div class="text-end">
                        <div class="cantidad-control">
                            <button class="btn btn-sm btn-outline-secondary" onclick="cambiarCantidad(${index}, -1)">-</button>
                            <span>${item.cantidad}</span>
                            <button class="btn btn-sm btn-outline-secondary" onclick="cambiarCantidad(${index}, 1)">+</button>
                        </div>
                        <div class="mt-1"><strong>$${(item.precio * item.cantidad).toFixed(2)}</strong></div>
                    </div>
                </div>
                <input type="text" class="form-control form-control-sm mt-1" 
                       placeholder="Notas..." 
                       value="${item.notas}"
                       onchange="actualizarNota(${index}, this.value)">
                <button class="btn btn-sm btn-link text-danger p-0" onclick="eliminarItem(${index})">
                    <i class="bi bi-trash"></i> Eliminar
                </button>
            </div>
        `).join('');
    }
    
    calcularTotales();
}

function cambiarCantidad(index, delta) {
    ticket[index].cantidad += delta;
    if (ticket[index].cantidad <= 0) {
        ticket.splice(index, 1);
    }
    actualizarTicket();
}

function eliminarItem(index) {
    ticket.splice(index, 1);
    actualizarTicket();
}

function actualizarNota(index, nota) {
    ticket[index].notas = nota;
}

function calcularTotales() {
    const subtotal = ticket.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);
    document.getElementById('subtotal').textContent = '$' + subtotal.toFixed(2);
    document.getElementById('total').textContent = '$' + subtotal.toFixed(2);
}

function cancelarTicket() {
    if (!confirm('¿Estás seguro de cancelar el ticket?')) return;
    ticket = [];
    mesaSeleccionada = null;
    pedidoActual = null;
    actualizarTicket();
    document.getElementById('infoMesa').textContent = 'Sin mesa';
    document.querySelectorAll('.mesa-item').forEach(item => {
        item.style.opacity = '1';
    });
}

function enviarPedido() {
    const tipo = document.querySelector('input[name="tipoPedido"]:checked').value;
    
    if (tipo === 'mesa' && !mesaSeleccionada) {
        alert('Selecciona una mesa');
        return;
    }
    
    if (ticket.length === 0) {
        alert('Agrega productos al ticket');
        return;
    }
    
    const data = {
        tipo: tipo,
        mesa_id: mesaSeleccionada,
        cliente_nombre: document.getElementById('clienteNombre').value,
        cliente_telefono: document.getElementById('clienteTelefono').value,
        productos: ticket.map(item => ({
            id: item.id,
            cantidad: item.cantidad,
            notas: item.notas
        }))
    };
    
    fetch('{{ route("pos.pedido.crear") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Pedido enviado correctamente');
            ticket = [];
            mesaSeleccionada = null;
            actualizarTicket();
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(e => {
        alert('Error al enviar el pedido');
        console.error(e);
    });
}

function cargarPedido(id) {
    fetch(`/pos/pedido/${id}`)
        .then(r => r.json())
        .then(data => {
            pedidoActual = data.pedido;
            // Mostrar opciones del pedido
        });
}

function cargarPedidoMesa(mesaId) {
    // Buscar pedido activo de la mesa
    fetch(`/pos/pedido/mesa/${mesaId}`)
        .then(r => r.json())
        .then(data => {
            if (data.pedido) {
                pedidoActual = data.pedido;
                // Cargar productos al ticket para agregar más
            }
        });
}

// Método de pago
document.getElementById('metodoPago').addEventListener('change', function() {
    const metodo = this.value;
    if (metodo === 'efectivo') {
        document.getElementById('campoEfectivo').classList.remove('d-none');
        document.getElementById('campoCambio').classList.remove('d-none');
        document.getElementById('campoReferencia').classList.add('d-none');
    } else {
        document.getElementById('campoEfectivo').classList.add('d-none');
        document.getElementById('campoCambio').classList.add('d-none');
        document.getElementById('campoReferencia').classList.remove('d-none');
    }
});

document.getElementById('montoRecibido').addEventListener('input', function() {
    const total = parseFloat(document.getElementById('totalCobrar').textContent.replace('$', ''));
    const recibido = parseFloat(this.value) || 0;
    const cambio = recibido - total;
    document.getElementById('cambio').textContent = '$' + (cambio > 0 ? cambio.toFixed(2) : '0.00');
});
</script>
@endsection

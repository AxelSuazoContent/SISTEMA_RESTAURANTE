<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CocinaController;
use App\Http\Controllers\POSController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Aquí es donde puedes registrar las rutas web para tu aplicación.
| Estas rutas son cargadas por el RouteServiceProvider.
|
*/

// Rutas públicas
Route::get('/', function () {
    return redirect()->route('login');
});

// Autenticación
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Cambiar contraseña
Route::get('/cambiar-password', [AuthController::class, 'showChangePassword'])
    ->name('password.change')
    ->middleware('auth');
Route::post('/cambiar-password', [AuthController::class, 'changePassword'])
    ->middleware('auth');

// Dashboard general
Route::get('/dashboard', function () {
    $user = auth()->user();
    return match($user->rol) {
        'admin' => redirect()->route('admin.dashboard'),
        'recepcionista' => redirect()->route('pos.index'),
        'cocina' => redirect()->route('cocina.index'),
        default => redirect()->route('login'),
    };
})->name('dashboard')->middleware('auth');

// ==================== RUTAS DE ADMINISTRADOR ====================
Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    
    // Dashboard
    Route::get('/dashboard', [AdminController::class, 'dashboard'])
        ->name('dashboard')
        ->middleware('can:admin');

    // Usuarios
    Route::middleware('can:admin')->group(function () {
        Route::get('/usuarios', [AdminController::class, 'usuariosIndex'])->name('usuarios.index');
        Route::get('/usuarios/crear', [AdminController::class, 'usuariosCreate'])->name('usuarios.create');
        Route::post('/usuarios', [AdminController::class, 'usuariosStore'])->name('usuarios.store');
        Route::get('/usuarios/{usuario}/editar', [AdminController::class, 'usuariosEdit'])->name('usuarios.edit');
        Route::put('/usuarios/{usuario}', [AdminController::class, 'usuariosUpdate'])->name('usuarios.update');
        Route::delete('/usuarios/{usuario}', [AdminController::class, 'usuariosDestroy'])->name('usuarios.destroy');
    });

    // Categorías
    Route::middleware('can:admin')->group(function () {
        Route::get('/categorias', [AdminController::class, 'categoriasIndex'])->name('categorias.index');
        Route::post('/categorias', [AdminController::class, 'categoriasStore'])->name('categorias.store');
        Route::put('/categorias/{categoria}', [AdminController::class, 'categoriasUpdate'])->name('categorias.update');
        Route::delete('/categorias/{categoria}', [AdminController::class, 'categoriasDestroy'])->name('categorias.destroy');
    });

    // Productos
    Route::middleware('can:admin')->group(function () {
        Route::get('/productos', [AdminController::class, 'productosIndex'])->name('productos.index');
        Route::get('/productos/crear', [AdminController::class, 'productosCreate'])->name('productos.create');
        Route::post('/productos', [AdminController::class, 'productosStore'])->name('productos.store');
        Route::get('/productos/{producto}/editar', [AdminController::class, 'productosEdit'])->name('productos.edit');
        Route::put('/productos/{producto}', [AdminController::class, 'productosUpdate'])->name('productos.update');
        Route::delete('/productos/{producto}', [AdminController::class, 'productosDestroy'])->name('productos.destroy');
    });

    // Mesas
    Route::middleware('can:admin')->group(function () {
        Route::get('/mesas', [AdminController::class, 'mesasIndex'])->name('mesas.index');
        Route::post('/mesas', [AdminController::class, 'mesasStore'])->name('mesas.store');
        Route::put('/mesas/{mesa}', [AdminController::class, 'mesasUpdate'])->name('mesas.update');
        Route::delete('/mesas/{mesa}', [AdminController::class, 'mesasDestroy'])->name('mesas.destroy');
    });

    // Reportes
    Route::middleware('can:admin')->group(function () {
        Route::get('/reportes/ventas', [AdminController::class, 'reporteVentas'])->name('reportes.ventas');
    });
});

// ==================== RUTAS DEL POS ====================
Route::middleware(['auth'])->prefix('pos')->name('pos.')->group(function () {
    
    // Vista principal
    Route::get('/', [POSController::class, 'index'])
        ->name('index')
        ->middleware('can:recepcionista');

    // Productos AJAX
    Route::get('/productos/categoria/{categoria}', [POSController::class, 'productosPorCategoria'])
        ->name('productos.categoria')
        ->middleware('can:recepcionista');

    // Pedidos
    Route::middleware('can:recepcionista')->group(function () {
        // Crear pedido
        Route::post('/pedido/crear', [POSController::class, 'crearPedido'])->name('pedido.crear');
        
        // Ver pedido
        Route::get('/pedido/{pedido}', [POSController::class, 'verPedido'])->name('pedido.ver');
        
        // Agregar productos a pedido existente
        Route::post('/pedido/{pedido}/agregar', [POSController::class, 'agregarProductos'])->name('pedido.agregar');
        
        // Cancelar pedido
        Route::post('/pedido/{pedido}/cancelar', [POSController::class, 'cancelarPedido'])->name('pedido.cancelar');
        
        // Procesar pago
        Route::post('/pedido/{pedido}/pagar', [POSController::class, 'procesarPago'])->name('pedido.pagar');
        
        // Marcar como entregado
        Route::post('/pedido/{pedido}/entregar', [POSController::class, 'marcarEntregado'])->name('pedido.entregar');
        
        // Imprimir ticket
        Route::get('/pedido/{pedido}/ticket', [POSController::class, 'imprimirTicket'])->name('pedido.ticket');
    });

    // Mesas
    Route::middleware('can:recepcionista')->group(function () {
        Route::post('/mesa/{mesa}/liberar', [POSController::class, 'liberarMesa'])->name('mesa.liberar');
        Route::post('/mesa/{mesa}/estado', [POSController::class, 'cambiarEstadoMesa'])->name('mesa.estado');
    });
});

// ==================== RUTAS DE COCINA ====================
Route::middleware(['auth'])->prefix('cocina')->name('cocina.')->group(function () {
    
    // Vista principal
    Route::get('/', [CocinaController::class, 'index'])
        ->name('index')
        ->middleware('can:cocina');

    // AJAX endpoints
    Route::middleware('can:cocina')->group(function () {
        // Obtener pedidos pendientes
        Route::get('/pedidos-pendientes', [CocinaController::class, 'pedidosPendientes'])
            ->name('pedidos.pendientes');
        
        // Ver pedido
        Route::get('/pedido/{pedido}', [CocinaController::class, 'verPedido'])
            ->name('pedido.ver');
        
        // Iniciar preparación de item
        Route::post('/detalle/{detalle}/iniciar', [CocinaController::class, 'iniciarPreparacion'])
            ->name('detalle.iniciar');
        
        // Marcar item como listo
        Route::post('/detalle/{detalle}/listo', [CocinaController::class, 'marcarListo'])
            ->name('detalle.listo');
        
        // Marcar item como entregado
        Route::post('/detalle/{detalle}/entregado', [CocinaController::class, 'marcarEntregado'])
            ->name('detalle.entregado');
        
        // Marcar pedido completo como listo
        Route::post('/pedido/{pedido}/listo', [CocinaController::class, 'marcarPedidoListo'])
            ->name('pedido.listo');
        
        // Check nuevos pedidos (polling)
        Route::get('/check-nuevos', [CocinaController::class, 'checkNuevosPedidos'])
            ->name('check.nuevos');
    });
});

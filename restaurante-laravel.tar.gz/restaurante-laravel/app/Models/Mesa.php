<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mesa extends Model
{
    use HasFactory;

    protected $table = 'mesas';

    protected $fillable = [
        'numero',
        'capacidad',
        'ubicacion',
        'estado',
    ];

    protected $casts = [
        'capacidad' => 'integer',
    ];

    /**
     * Estados posibles de una mesa
     */
    const ESTADO_DISPONIBLE = 'disponible';
    const ESTADO_OCUPADA = 'ocupada';
    const ESTADO_RESERVADA = 'reservada';
    const ESTADO_LIMPIEZA = 'limpieza';

    /**
     * Relación con pedidos
     */
    public function pedidos()
    {
        return $this->hasMany(Pedido::class);
    }

    /**
     * Pedido activo de la mesa
     */
    public function pedidoActivo()
    {
        return $this->hasOne(Pedido::class)
            ->whereIn('estado', ['pendiente', 'preparando', 'listo'])
            ->latest();
    }

    /**
     * Scope para mesas disponibles
     */
    public function scopeDisponibles($query)
    {
        return $query->where('estado', self::ESTADO_DISPONIBLE);
    }

    /**
     * Verificar si la mesa está disponible
     */
    public function estaDisponible(): bool
    {
        return $this->estado === self::ESTADO_DISPONIBLE;
    }

    /**
     * Obtener el estado formateado
     */
    public function getEstadoFormateadoAttribute(): string
    {
        $estados = [
            'disponible' => 'Disponible',
            'ocupada' => 'Ocupada',
            'reservada' => 'Reservada',
            'limpieza' => 'En limpieza',
        ];

        return $estados[$this->estado] ?? $this->estado;
    }

    /**
     * Obtener el color del estado
     */
    public function getEstadoColorAttribute(): string
    {
        $colores = [
            'disponible' => 'success',
            'ocupada' => 'danger',
            'reservada' => 'warning',
            'limpieza' => 'info',
        ];

        return $colores[$this->estado] ?? 'secondary';
    }
}

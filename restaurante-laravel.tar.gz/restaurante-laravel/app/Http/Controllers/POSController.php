<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Mesa;
use App\Models\Pedido;
use App\Models\Producto;
use App\Models\Pago;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class POSController extends Controller
{
    /**
     * Vista principal del POS
     */
    public function index()
    {
        $mesas = Mesa::orderBy('numero')->get();
        $categorias = Categoria::where('activo', true)
            ->with(['productos' => function ($query) {
                $query->where('activo', true)->orderBy('nombre');
            }])
            ->orderBy('orden')
            ->get();

        $pedidosActivos = Pedido::with(['mesa', 'detalles.producto'])
            ->whereIn('estado', ['pendiente', 'preparando', 'listo'])
            ->orderBy('created_at', 'desc')
            ->get();

        return view('pos.index', compact('mesas', 'categorias', 'pedidosActivos'));
    }

    /**
     * Obtener productos por categoría (AJAX)
     */
    public function productosPorCategoria(Categoria $categoria)
    {
        $productos = Producto::where('categoria_id', $categoria->id)
            ->where('activo', true)
            ->orderBy('nombre')
            ->get(['id', 'nombre', 'precio', 'stock', 'imagen']);

        return response()->json($productos);
    }

    /**
     * Crear nuevo pedido
     */
    public function crearPedido(Request $request)
    {
        $request->validate([
            'tipo' => 'required|in:mesa,llevar,domicilio',
            'mesa_id' => 'required_if:tipo,mesa|nullable|exists:mesas,id',
            'cliente_nombre' => 'nullable|string|max:255',
            'cliente_telefono' => 'nullable|string|max:20',
            'productos' => 'required|array|min:1',
            'productos.*.id' => 'required|exists:productos,id',
            'productos.*.cantidad' => 'required|integer|min:1',
            'productos.*.notas' => 'nullable|string',
            'notas' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            // Crear el pedido
            $pedido = Pedido::create([
                'mesa_id' => $request->mesa_id,
                'usuario_id' => Auth::id(),
                'cliente_nombre' => $request->cliente_nombre,
                'cliente_telefono' => $request->cliente_telefono,
                'estado' => 'pendiente',
                'tipo' => $request->tipo,
                'notas' => $request->notas,
            ]);

            // Agregar detalles
            foreach ($request->productos as $item) {
                $producto = Producto::find($item['id']);
                
                $pedido->detalles()->create([
                    'producto_id' => $item['id'],
                    'cantidad' => $item['cantidad'],
                    'precio_unitario' => $producto->precio,
                    'notas' => $item['notas'] ?? null,
                    'estado' => 'pendiente',
                ]);

                // Descontar stock
                $producto->stock -= $item['cantidad'];
                $producto->save();
            }

            // Calcular total
            $pedido->actualizarTotal();

            // Actualizar estado de la mesa si es pedido en mesa
            if ($request->mesa_id) {
                $mesa = Mesa::find($request->mesa_id);
                $mesa->estado = 'ocupada';
                $mesa->save();
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'pedido' => $pedido->load(['detalles.producto', 'mesa']),
                'message' => 'Pedido creado correctamente.',
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Error al crear el pedido: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Agregar productos a un pedido existente
     */
    public function agregarProductos(Request $request, Pedido $pedido)
    {
        if (!$pedido->puedeEditarse()) {
            return response()->json([
                'success' => false,
                'message' => 'No se pueden agregar productos a este pedido.',
            ], 422);
        }

        $request->validate([
            'productos' => 'required|array|min:1',
            'productos.*.id' => 'required|exists:productos,id',
            'productos.*.cantidad' => 'required|integer|min:1',
            'productos.*.notas' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            foreach ($request->productos as $item) {
                $producto = Producto::find($item['id']);
                
                // Verificar si ya existe el producto en el pedido
                $detalleExistente = $pedido->detalles()
                    ->where('producto_id', $item['id'])
                    ->where('estado', 'pendiente')
                    ->first();

                if ($detalleExistente && empty($item['notas'])) {
                    // Actualizar cantidad
                    $detalleExistente->cantidad += $item['cantidad'];
                    $detalleExistente->save();
                } else {
                    // Crear nuevo detalle
                    $pedido->detalles()->create([
                        'producto_id' => $item['id'],
                        'cantidad' => $item['cantidad'],
                        'precio_unitario' => $producto->precio,
                        'notas' => $item['notas'] ?? null,
                        'estado' => 'pendiente',
                    ]);
                }

                // Descontar stock
                $producto->stock -= $item['cantidad'];
                $producto->save();
            }

            // Recalcular total
            $pedido->actualizarTotal();

            DB::commit();

            return response()->json([
                'success' => true,
                'pedido' => $pedido->load(['detalles.producto', 'mesa']),
                'message' => 'Productos agregados correctamente.',
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Error al agregar productos: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Ver detalle de un pedido
     */
    public function verPedido(Pedido $pedido)
    {
        return response()->json([
            'pedido' => $pedido->load(['detalles.producto.categoria', 'mesa', 'usuario', 'pago']),
        ]);
    }

    /**
     * Cancelar pedido
     */
    public function cancelarPedido(Request $request, Pedido $pedido)
    {
        if (!$pedido->puedeCancelarse()) {
            return response()->json([
                'success' => false,
                'message' => 'Este pedido no puede ser cancelado.',
            ], 422);
        }

        $request->validate([
            'motivo' => 'required|string|min:5',
        ]);

        DB::beginTransaction();

        try {
            // Devolver stock
            foreach ($pedido->detalles as $detalle) {
                $producto = $detalle->producto;
                $producto->stock += $detalle->cantidad;
                $producto->save();
            }

            // Actualizar pedido
            $pedido->estado = 'cancelado';
            $pedido->notas = ($pedido->notas ? $pedido->notas . "\n" : '') . 
                'Cancelado: ' . $request->motivo;
            $pedido->save();

            // Liberar mesa
            if ($pedido->mesa) {
                $pedido->mesa->estado = 'disponible';
                $pedido->mesa->save();
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Pedido cancelado correctamente.',
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Error al cancelar el pedido: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Procesar pago de un pedido
     */
    public function procesarPago(Request $request, Pedido $pedido)
    {
        if ($pedido->estado === 'pagado') {
            return response()->json([
                'success' => false,
                'message' => 'Este pedido ya ha sido pagado.',
            ], 422);
        }

        $request->validate([
            'metodo_pago' => 'required|in:efectivo,tarjeta,transferencia,otro',
            'monto_recibido' => 'required|numeric|min:' . $pedido->total,
            'referencia' => 'nullable|string|max:255',
        ]);

        DB::beginTransaction();

        try {
            $cambio = $request->monto_recibido - $pedido->total;

            // Crear el pago
            Pago::create([
                'pedido_id' => $pedido->id,
                'metodo_pago' => $request->metodo_pago,
                'monto' => $pedido->total,
                'cambio' => $cambio,
                'referencia' => $request->referencia,
                'notas' => $request->notas,
            ]);

            // Actualizar pedido
            $pedido->estado = 'pagado';
            $pedido->fecha_completado = now();
            $pedido->save();

            // Liberar mesa
            if ($pedido->mesa) {
                $pedido->mesa->estado = 'disponible';
                $pedido->mesa->save();
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'cambio' => $cambio,
                'message' => 'Pago procesado correctamente.',
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Error al procesar el pago: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Cambiar estado de un pedido a entregado
     */
    public function marcarEntregado(Pedido $pedido)
    {
        if ($pedido->estado !== 'listo') {
            return response()->json([
                'success' => false,
                'message' => 'El pedido debe estar listo para marcarlo como entregado.',
            ], 422);
        }

        $pedido->estado = 'entregado';
        $pedido->save();

        return response()->json([
            'success' => true,
            'message' => 'Pedido marcado como entregado.',
        ]);
    }

    /**
     * Liberar mesa manualmente
     */
    public function liberarMesa(Mesa $mesa)
    {
        // Verificar si tiene pedidos activos
        $pedidoActivo = Pedido::where('mesa_id', $mesa->id)
            ->whereIn('estado', ['pendiente', 'preparando', 'listo'])
            ->first();

        if ($pedidoActivo) {
            return response()->json([
                'success' => false,
                'message' => 'La mesa tiene un pedido activo.',
            ], 422);
        }

        $mesa->estado = 'disponible';
        $mesa->save();

        return response()->json([
            'success' => true,
            'message' => 'Mesa liberada correctamente.',
        ]);
    }

    /**
     * Cambiar estado de mesa
     */
    public function cambiarEstadoMesa(Request $request, Mesa $mesa)
    {
        $request->validate([
            'estado' => 'required|in:disponible,ocupada,reservada,limpieza',
        ]);

        $mesa->estado = $request->estado;
        $mesa->save();

        return response()->json([
            'success' => true,
            'message' => 'Estado de mesa actualizado.',
        ]);
    }

    /**
     * Imprimir ticket (vista para impresión)
     */
    public function imprimirTicket(Pedido $pedido)
    {
        return view('pos.ticket', compact('pedido'));
    }
}

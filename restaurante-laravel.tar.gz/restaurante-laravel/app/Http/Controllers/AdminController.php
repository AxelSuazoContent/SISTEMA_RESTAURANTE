<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Mesa;
use App\Models\Pedido;
use App\Models\Producto;
use App\Models\User;
use App\Models\Pago;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class AdminController extends Controller
{
    /**
     * Dashboard del administrador
     */
    public function dashboard()
    {
        // Estadísticas del día
        $hoy = Carbon::today();
        $ventasHoy = Pedido::whereDate('created_at', $hoy)
            ->where('estado', 'pagado')
            ->sum('total');
        
        $pedidosHoy = Pedido::whereDate('created_at', $hoy)->count();
        
        $pedidosActivos = Pedido::whereIn('estado', ['pendiente', 'preparando', 'listo'])->count();
        
        // Productos con bajo stock
        $productosBajoStock = Producto::where('stock', '<', 10)
            ->where('activo', true)
            ->count();

        // Pedidos recientes
        $pedidosRecientes = Pedido::with(['mesa', 'usuario'])
            ->orderBy('created_at', 'desc')
            ->take(10)
            ->get();

        // Ventas de la semana
        $inicioSemana = Carbon::now()->startOfWeek();
        $ventasSemana = Pedido::where('created_at', '>=', $inicioSemana)
            ->where('estado', 'pagado')
            ->selectRaw('DATE(created_at) as fecha, SUM(total) as total')
            ->groupBy('fecha')
            ->orderBy('fecha')
            ->get();

        // Productos más vendidos
        $productosTop = \DB::table('detalles_pedido')
            ->join('productos', 'detalles_pedido.producto_id', '=', 'productos.id')
            ->select('productos.nombre', \DB::raw('SUM(detalles_pedido.cantidad) as total_vendido'))
            ->groupBy('productos.id', 'productos.nombre')
            ->orderByDesc('total_vendido')
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'ventasHoy',
            'pedidosHoy',
            'pedidosActivos',
            'productosBajoStock',
            'pedidosRecientes',
            'ventasSemana',
            'productosTop'
        ));
    }

    // ==================== USUARIOS ====================

    /**
     * Lista de usuarios
     */
    public function usuariosIndex()
    {
        $usuarios = User::orderBy('nombre')->paginate(20);
        return view('admin.usuarios.index', compact('usuarios'));
    }

    /**
     * Formulario para crear usuario
     */
    public function usuariosCreate()
    {
        return view('admin.usuarios.create');
    }

    /**
     * Guardar nuevo usuario
     */
    public function usuariosStore(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'rol' => 'required|in:admin,recepcionista,cocina',
            'telefono' => 'nullable|string|max:20',
        ]);

        User::create([
            'nombre' => $request->nombre,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'rol' => $request->rol,
            'telefono' => $request->telefono,
            'activo' => $request->boolean('activo', true),
        ]);

        return redirect()->route('admin.usuarios.index')
            ->with('success', 'Usuario creado correctamente.');
    }

    /**
     * Formulario para editar usuario
     */
    public function usuariosEdit(User $usuario)
    {
        return view('admin.usuarios.edit', compact('usuario'));
    }

    /**
     * Actualizar usuario
     */
    public function usuariosUpdate(Request $request, User $usuario)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $usuario->id,
            'rol' => 'required|in:admin,recepcionista,cocina',
            'telefono' => 'nullable|string|max:20',
        ]);

        $data = [
            'nombre' => $request->nombre,
            'email' => $request->email,
            'rol' => $request->rol,
            'telefono' => $request->telefono,
            'activo' => $request->boolean('activo', true),
        ];

        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        }

        $usuario->update($data);

        return redirect()->route('admin.usuarios.index')
            ->with('success', 'Usuario actualizado correctamente.');
    }

    /**
     * Eliminar usuario
     */
    public function usuariosDestroy(User $usuario)
    {
        // No permitir eliminar el último administrador
        if ($usuario->rol === 'admin' && User::where('rol', 'admin')->count() <= 1) {
            return back()->with('error', 'No puedes eliminar el último administrador.');
        }

        $usuario->delete();

        return redirect()->route('admin.usuarios.index')
            ->with('success', 'Usuario eliminado correctamente.');
    }

    // ==================== CATEGORÍAS ====================

    /**
     * Lista de categorías
     */
    public function categoriasIndex()
    {
        $categorias = Categoria::orderBy('orden')->paginate(20);
        return view('admin.categorias.index', compact('categorias'));
    }

    /**
     * Guardar nueva categoría
     */
    public function categoriasStore(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'color' => 'required|string|max:7',
            'orden' => 'nullable|integer',
        ]);

        Categoria::create($request->all());

        return redirect()->route('admin.categorias.index')
            ->with('success', 'Categoría creada correctamente.');
    }

    /**
     * Actualizar categoría
     */
    public function categoriasUpdate(Request $request, Categoria $categoria)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'color' => 'required|string|max:7',
            'orden' => 'nullable|integer',
            'activo' => 'boolean',
        ]);

        $categoria->update($request->all());

        return redirect()->route('admin.categorias.index')
            ->with('success', 'Categoría actualizada correctamente.');
    }

    /**
     * Eliminar categoría
     */
    public function categoriasDestroy(Categoria $categoria)
    {
        // Verificar si tiene productos
        if ($categoria->productos()->count() > 0) {
            return back()->with('error', 'No puedes eliminar una categoría con productos.');
        }

        $categoria->delete();

        return redirect()->route('admin.categorias.index')
            ->with('success', 'Categoría eliminada correctamente.');
    }

    // ==================== PRODUCTOS ====================

    /**
     * Lista de productos
     */
    public function productosIndex()
    {
        $productos = Producto::with('categoria')
            ->orderBy('nombre')
            ->paginate(20);
        
        $categorias = Categoria::where('activo', true)->orderBy('nombre')->get();
        
        return view('admin.productos.index', compact('productos', 'categorias'));
    }

    /**
     * Formulario para crear producto
     */
    public function productosCreate()
    {
        $categorias = Categoria::where('activo', true)->orderBy('nombre')->get();
        return view('admin.productos.create', compact('categorias'));
    }

    /**
     * Guardar nuevo producto
     */
    public function productosStore(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio' => 'required|numeric|min:0',
            'costo' => 'nullable|numeric|min:0',
            'categoria_id' => 'required|exists:categorias,id',
            'stock' => 'nullable|integer|min:0',
            'preparacion_minutos' => 'nullable|integer|min:1',
            'imagen' => 'nullable|image|max:2048',
        ]);

        $data = $request->except('imagen');

        if ($request->hasFile('imagen')) {
            $data['imagen'] = $request->file('imagen')->store('productos', 'public');
        }

        Producto::create($data);

        return redirect()->route('admin.productos.index')
            ->with('success', 'Producto creado correctamente.');
    }

    /**
     * Formulario para editar producto
     */
    public function productosEdit(Producto $producto)
    {
        $categorias = Categoria::where('activo', true)->orderBy('nombre')->get();
        return view('admin.productos.edit', compact('producto', 'categorias'));
    }

    /**
     * Actualizar producto
     */
    public function productosUpdate(Request $request, Producto $producto)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio' => 'required|numeric|min:0',
            'costo' => 'nullable|numeric|min:0',
            'categoria_id' => 'required|exists:categorias,id',
            'stock' => 'nullable|integer|min:0',
            'preparacion_minutos' => 'nullable|integer|min:1',
            'imagen' => 'nullable|image|max:2048',
            'activo' => 'boolean',
        ]);

        $data = $request->except('imagen');

        if ($request->hasFile('imagen')) {
            // Eliminar imagen anterior si existe
            if ($producto->imagen) {
                \Storage::disk('public')->delete($producto->imagen);
            }
            $data['imagen'] = $request->file('imagen')->store('productos', 'public');
        }

        $producto->update($data);

        return redirect()->route('admin.productos.index')
            ->with('success', 'Producto actualizado correctamente.');
    }

    /**
     * Eliminar producto
     */
    public function productosDestroy(Producto $producto)
    {
        // Eliminar imagen si existe
        if ($producto->imagen) {
            \Storage::disk('public')->delete($producto->imagen);
        }

        $producto->delete();

        return redirect()->route('admin.productos.index')
            ->with('success', 'Producto eliminado correctamente.');
    }

    // ==================== MESAS ====================

    /**
     * Lista de mesas
     */
    public function mesasIndex()
    {
        $mesas = Mesa::orderBy('numero')->paginate(20);
        return view('admin.mesas.index', compact('mesas'));
    }

    /**
     * Guardar nueva mesa
     */
    public function mesasStore(Request $request)
    {
        $request->validate([
            'numero' => 'required|integer|unique:mesas',
            'capacidad' => 'required|integer|min:1',
            'ubicacion' => 'nullable|string|max:255',
        ]);

        Mesa::create($request->all());

        return redirect()->route('admin.mesas.index')
            ->with('success', 'Mesa creada correctamente.');
    }

    /**
     * Actualizar mesa
     */
    public function mesasUpdate(Request $request, Mesa $mesa)
    {
        $request->validate([
            'numero' => 'required|integer|unique:mesas,numero,' . $mesa->id,
            'capacidad' => 'required|integer|min:1',
            'ubicacion' => 'nullable|string|max:255',
        ]);

        $mesa->update($request->all());

        return redirect()->route('admin.mesas.index')
            ->with('success', 'Mesa actualizada correctamente.');
    }

    /**
     * Eliminar mesa
     */
    public function mesasDestroy(Mesa $mesa)
    {
        // Verificar si tiene pedidos
        if ($mesa->pedidos()->count() > 0) {
            return back()->with('error', 'No puedes eliminar una mesa con pedidos.');
        }

        $mesa->delete();

        return redirect()->route('admin.mesas.index')
            ->with('success', 'Mesa eliminada correctamente.');
    }

    // ==================== REPORTES ====================

    /**
     * Reporte de ventas
     */
    public function reporteVentas(Request $request)
    {
        $fechaInicio = $request->date('fecha_inicio', Carbon::now()->startOfMonth());
        $fechaFin = $request->date('fecha_fin', Carbon::now());

        $ventas = Pedido::whereBetween('created_at', [$fechaInicio, $fechaFin->copy()->endOfDay()])
            ->where('estado', 'pagado')
            ->with(['mesa', 'usuario', 'pago'])
            ->orderBy('created_at', 'desc')
            ->paginate(50);

        $totalVentas = Pedido::whereBetween('created_at', [$fechaInicio, $fechaFin->copy()->endOfDay()])
            ->where('estado', 'pagado')
            ->sum('total');

        $totalPedidos = Pedido::whereBetween('created_at', [$fechaInicio, $fechaFin->copy()->endOfDay()])
            ->where('estado', 'pagado')
            ->count();

        return view('admin.reportes.ventas', compact(
            'ventas',
            'totalVentas',
            'totalPedidos',
            'fechaInicio',
            'fechaFin'
        ));
    }
}
